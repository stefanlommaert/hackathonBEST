### OBJECTIVE
"""
In the future, everyone will be using flying cars that behave as follows:
- They can go at a fixed speed for a fixed amount of seconds
- After that, they need to stand still for another fixed amount of seconds
See example on pdf.

Given the following car descriptions, what distance was the winning car at after 2503 seconds?
- Volkswagen can fly 22 km/s for 8 seconds, but then must rest for 165 seconds.
- Fiat can fly 8 km/s for 17 seconds, but then must rest for 114 seconds.
- Mercedes can fly 18 km/s for 6 seconds, but then must rest for 103 seconds.
- Skoda can fly 25 km/s for 6 seconds, but then must rest for 145 seconds.
- Audi can fly 11 km/s for 12 seconds, but then must rest for 125 seconds.
- Ford can fly 21 km/s for 6 seconds, but then must rest for 121 seconds.
- Volvo can fly 18 km/s for 3 seconds, but then must rest for 50 seconds.
- BMW can fly 20 km/s for 4 seconds, but then must rest for 75 seconds.
- Renault can fly 7 km/s for 20 seconds, but then must rest for 119 seconds.
"""

def distance_after_seconds(seconds):
    # TODO
    pass

### OUTPUT - DO NOT TOUCH
print(distance_after_seconds(2503))
### END OUTPUT