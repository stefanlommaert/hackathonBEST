### OBJECTIVE
"""
You’ve traveled to the future and poetry is very weird there. All they care about are palindromes, kinda like all
we care about is rhyming maybe? Anyway you’ve stumbled into a poetry contest, which is kind of like a
sophisticated rap battle. You have some sentences in your head, but you need to split them up into
palindromes.
Your goal is to figure out the minimal number of cuts needed to split a string up into palindromes.
"""

def cut_palindrome() -> int:
    # TODO
    pass

### OUTPUT - DO NOT TOUCH
print(cut_palindrome())
### END OUTPUT

### EXAMPLE OUTPUT - YOU MAY UNCOMMENT THIS LINE TO TEST YOUR CODE
### assert cut_palindrome("test") == 3
### assert cut_palindrome("lallol") == 1
